1 - HTML / JS
2 - React / Web3

