import React from 'react';
import Body from './components/Body';
import Header from './components/Header';

function App() {    
    return (
        <div className="App">
            <header className="App-header">
                <Header />
                <br/>
                <Body />
            </header>
        </div>
    );
};

export default App;